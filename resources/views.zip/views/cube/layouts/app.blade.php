@include('cube.includes.header')
</head>
     <!-- Left Panel -->
    <body>
     <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
         <!-- /#header -->
@section('mini_top_nav')
@show
@section('content')
@show

@include('cube.includes.footer')

