@include('includes.header')
 
@include('includes.nav')
 
@section('content')
@show
@include('includes.footer')